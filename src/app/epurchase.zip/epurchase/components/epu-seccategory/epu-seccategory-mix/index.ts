export * from './epu-seccategory-mix.component';
