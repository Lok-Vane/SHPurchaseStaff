export * from './epu-fircategory-query.component';
