export * from './epu-fircategory-mix.component';
