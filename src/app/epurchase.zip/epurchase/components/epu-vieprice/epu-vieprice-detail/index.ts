export * from './epu-vieprice-detail.component';
