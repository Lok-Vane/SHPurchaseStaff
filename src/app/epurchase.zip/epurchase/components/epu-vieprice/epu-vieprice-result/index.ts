export * from './epu-vieprice-result.component';
