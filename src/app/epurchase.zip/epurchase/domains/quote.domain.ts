// 材料档案
export interface Pro {
    categorySecName?: string;
    code?: string;
    producName?: string;
    specifications?: string;
    metering?: string;
    productBrand?: string;
    createdByName?: string;
    createdTime?: string;
    modifyByName?: string;
    modifyTime?: string;
    remark?: string;
}
