export interface EpuMaterial {
    categorySecName?: string;
    categorySecCode?: string;
    code?: string;
    producName?: string;
    specifications?: string;
    metering?: string;
    productBrand?: string;
    createdByName?: string;
    createdTime?: string;
    modifyByName?: string;
    modifyTime?: string;
    remark?: string;
}
