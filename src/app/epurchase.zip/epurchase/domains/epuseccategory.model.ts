export interface EpuSecCategory {
    code?: string;
    categoryName?: string;
    firstCode?: string;
    categoryFirName?: string;
    firstCategoryName?: string;
    createdByName?: string;
    createdTime?: string;
    modifyByName?: string;
    modifyTime?: string;
    remark?: string;
}
