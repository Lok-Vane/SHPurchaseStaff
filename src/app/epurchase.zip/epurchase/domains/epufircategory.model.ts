export interface EpuFirCategory {
    bizId?: string;
    code?: string;
    categoryFirName?: string;
    createdByName?: string;
    createdTime?: string;
    modifyByName?: string;
    modifyTime?: string;
    remark?: string;
}
