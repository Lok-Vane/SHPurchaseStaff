// 中标结果页面的料品实体
export interface ProductInfo {
    producName?: string;
    specifications?: string;
    metering?: string;
    purchaseNum?: string;
    errorLimit?: string;
    remark?: string;
    pcId?: string;
}
